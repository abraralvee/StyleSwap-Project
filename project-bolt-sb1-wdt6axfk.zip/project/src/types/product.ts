export interface Product {
  _id: string;
  name: string;
  size: string;
  color: string;
  gender: string;
  condition: string;
  image: string;
  price: string;
  duration: string;
}